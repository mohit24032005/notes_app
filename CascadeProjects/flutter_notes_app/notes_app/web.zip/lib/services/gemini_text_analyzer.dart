import 'package:flutter/foundation.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

class GeminiTextAnalyzer {
  late final GenerativeModel _model;

  GeminiTextAnalyzer(String apiKey) {
    if (apiKey.isEmpty) {
      throw ArgumentError('Gemini API key is missing');
    }

    _model = GenerativeModel(
      model: 'gemini-1.5-flash',
      apiKey: apiKey,
    );
  }

  Future<String> summarizeNote(String content) async {
    if (content.trim().isEmpty) {
      return '';
    }

    try {
      final response = await _model.generateContent([
        Content.text('Summarize this note in 1-2 short sentences. Keep it concise and clear. Note content:\n$content'),
      ]);
      return response.text?.trim() ?? '';
    } catch (e) {
      debugPrint('Gemini summarizeNote error: $e');
      rethrow;
    }
  }
}
